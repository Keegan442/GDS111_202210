﻿using System.Net.Mail;
using System.Text.RegularExpressions;

namespace BasicSocial
{
    public abstract class Validation
    {
        public static string GetConnected()
        {
            return @"Server=sql.neit.edu,4500\studentsqlserver;Database=SE256_DKnight;User Id=SE256_DKnight;Password=008009610;"; // set the who/what/where for our db
        }

        /// <summary>
        /// Function that makes sure a string only contains an INT.
        /// </summary>
        /// <param name="stringInput"></param>
        public static bool IntOnly(string stringInput)
        {
            bool valid = int.TryParse(stringInput, out _); // _ discarded. Only used for testing the string.

            return valid;
        }

        /// <summary>
        /// Function that makes sure a string only contains a DOUBLE.
        /// </summary>
        /// <param name="stringInput"></param>
        public static bool DoubleOnly(string stringInput)
        {
            bool valid = double.TryParse(stringInput, out _); // _ discarded. Only used for testing the string.

            return valid;
        }

        /// <summary>
        /// Function that makes sure an entry is not blank.
        /// </summary>
        /// <param name="temp"></param>
        public static bool IsItFilledIn(string temp)
        {
            bool result = temp.Length > 0;

            return result;
        }

        /// <summary>
        /// Function that compares string input vs MailAddress to see if it is a potential valid email.
        /// </summary>
        /// <param name="email"></param>
        public static bool IsValidMailAddress(string email)
        {
            bool valid = true;

            try
            {
                MailAddress emailAddress = new MailAddress(email);
            }
            catch
            {
                valid = false;
            }

            return valid;
        }

        /// <summary>
        /// Function that compares email vs a regex.
        /// </summary>
        /// <param name="stringInput"></param>
        public static bool IsValidEmail(string stringInput)
        {
            return Regex.IsMatch(stringInput, @"^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$");
        }

        /// <summary>
        /// Function that compares string vs our motif to ensure valid phone numbers.
        /// </summary>
        /// <param name="number"></param>
        public static bool IsValidPhoneNumberFormat(string number)
        {
            const string motif = @"^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$"; // Regular expression used to validate a phone number.

            return Regex.IsMatch(number, motif);
        }
    }
}