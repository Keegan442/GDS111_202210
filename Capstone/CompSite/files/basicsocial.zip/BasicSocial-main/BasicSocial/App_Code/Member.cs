﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using BasicSocial.Backend;

namespace BasicSocial
{
    public class Member
    {
        private string _email;
        private string _password;

        private string _firstName;
        private string _lastName;

        private DateTime _birthday;

        private int _isAdmin = 0; // set to 0 to set to False in SQL.
        private double _accountBalance = 0.0; // set to 0.0 to populate SQL.

        private int _membershipId;

        public string Feedback { get; private set; } = "";

        private static DateTime MemberSince => DateTime.Now;

        public string Email
        {
            get => _email;
            set
            {
                if (Validation.IsValidEmail(value))
                {
                    _email = value;
                }
                else
                {
                    Feedback += "<br>ERROR: Not a valid email format.<br>";
                }
            }
        }

        public string Password
        {
            get => _password;
            set
            {
                if (Validation.IsItFilledIn(value))
                {
                    _password = value;
                }
                else
                {
                    Feedback += "<br>ERROR: Password must be filled in.<br>";
                }
            }
        }

        public string FirstName
        {
            get => _firstName;
            set
            {
                if (Validation.IsItFilledIn(value))
                {
                    _firstName = value;
                }
                else
                {
                    Feedback += "<br>ERROR: First Name must be filled in.<br>";
                }
            }
        }

        public string LastName
        {
            get => _lastName;
            set
            {
                if (Validation.IsItFilledIn(value))
                {
                    _lastName = value;
                }
                else
                {
                    Feedback += "<br>ERROR: Last Name must be filled in.<br>";
                }
            }
        }

        public DateTime Birthday
        {
            get => _birthday;
            set
            {
                if (value.AddYears(13) > DateTime.Now)
                {
                    Feedback += "<br>ERROR: Age must be 13 or older.<br>";
                }
                else
                {
                    _birthday = value;
                }

            }
        }

        public int MembershipId
        {
            get => _membershipId;
            set
            {
                if (value >= 0)
                {
                    _membershipId = value;
                }
                else
                {
                    Feedback += "\nERROR: Sorry you entered an invalid Membership ID.";
                }
            }
        }

        public double AccountBalance
        {
            get => _accountBalance;
            set
            {
                if (value >= 0)
                {
                    _accountBalance = value;
                }
                else
                {
                    Feedback += "\nERROR: Account Balance must be a DOUBLE.";
                }
            }

        }

        public int IsAdmin
        {
            get => _isAdmin;
            set
            {
                if (value >= 0)
                {
                    _isAdmin = value;
                }
                else
                {
                    Feedback += "\nERROR: VIP must be True or False.";
                }
            }
        }

        /// <summary>
        /// Searches the Members table and returns a DataSet of matching members, excluding the current member and their friends.
        /// </summary>
        /// <param name="name">The name of the member to search for.</param>
        /// <returns>A DataSet containing the matching members from the Members table.</returns>
        /// <remarks>
        /// This method uses a left outer join to exclude members who are already friends or have pending friend requests with the current member.
        /// The current member's ID and email are retrieved from the current session.
        /// </remarks>
        public DataSet SearchMembers_DS(string name)
        {
            DataSet ds = new DataSet();

            using (SqlConnection conn = new SqlConnection(Validation.GetConnected()))
            {
                Dictionary<string, object> parameters = new Dictionary<string, object>();

                // Base query
                string baseQuery = @"
                    SELECT DISTINCT m.Member_ID, m.Email, m.FirstName, m.LastName
                    FROM Members m
                    LEFT OUTER JOIN (
                        SELECT Member_Email_From, Member_Email_To
                        FROM FriendStatus
                        WHERE (Member_Email_To = @MemberEmail OR Member_Email_From = @MemberEmail)
                              AND (IsFriend = 1 OR Requested = 1)
                    ) as fs
                    ON m.Email = fs.Member_Email_From OR m.Email = fs.Member_Email_To
                    WHERE m.Member_ID <> @ExcludedMemberId
                    AND fs.Member_Email_From IS NULL 
                    AND fs.Member_Email_To IS NULL";

                parameters["@ExcludedMemberId"] = HttpContext.Current.Session["Member_ID"].ToString();
                parameters["@MemberEmail"] = HttpContext.Current.Session["UName"].ToString();

                if (!string.IsNullOrEmpty(name))
                {
                    baseQuery += " AND (m.FirstName LIKE @FirstName OR m.LastName LIKE @LastName)";
                    parameters["@FirstName"] = "%" + name + "%";
                    parameters["@LastName"] = "%" + name + "%";
                }

                SqlCommand comm = SharedFunctions.CreateSqlCommand(conn, baseQuery, parameters);

                // Use the command to create a Data Adapter
                using (SqlDataAdapter da = new SqlDataAdapter(comm))
                {
                    conn.Open();

                    da.Fill(ds, "Member_Temp");
                }
            }

            return ds;
        }

        /// <summary>
        /// Searches the Members table based on the provided name criteria and returns a DataSet of matching members.
        /// </summary>
        /// <param name="strName">The name to search for within the Members table. Can match either the first name or last name of the member.</param>
        /// <returns>A DataSet containing members from the Members table that match the specified criteria.</returns>
        /// <remarks>
        /// This method allows administrators to search for members based on their first or last names. 
        /// The search is case-insensitive and uses a LIKE query for partial name matching.
        /// </remarks>
        public DataSet AdminSearchMembers_DS(string strName)
        {
            //Create a dataset to return filled
            DataSet ds = new DataSet();

            //Create a command for our SQL statement
            SqlCommand comm = new SqlCommand();

            //Select statement
            string strSQL = "SELECT Member_ID, Email, FirstName, LastName FROM Members WHERE 0=0";

            //If the First/Last Name is filled in, include it as a search criteria
            if (strName.Length > 0)
            {
                strSQL += " AND (FirstName LIKE @FirstName OR LastName LIKE @LastName)";
                comm.Parameters.AddWithValue("@FirstName", "%" + strName + "%");
                comm.Parameters.AddWithValue("@LastName", "%" + strName + "%");
            }

            //Create DB tools and configure
            SqlConnection conn = new SqlConnection();

            string strConn = Validation.GetConnected();
            conn.ConnectionString = strConn;

            comm.Connection = conn;
            comm.CommandText = strSQL;

            //Create Data Adapter
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = comm;

            conn.Open();

            da.Fill(ds, "Member_Temp");

            conn.Close();

            return ds;
        }

        /// <summary>
        /// Adds a new member to the Members database table.
        /// </summary>
        /// <remarks>
        /// This method attempts to insert a new member record into the Members table using the properties set on the instance.
        /// Before inserting, it checks if an existing record with the provided email already exists.
        /// Upon successful addition, it sets a session for the user and redirects to the MembershipPanel.
        /// </remarks>
        /// <returns>
        /// A string message indicating the result of the operation. It will either show the number of affected records or an error message.
        /// </returns>
        public string AddMember()
        {
            string result;

            SqlCommand command = new SqlCommand
            {
                CommandText = "INSERT INTO Members (Email, Password, FirstName, LastName, Birthday, IsAdmin, AccountBalance, MemberSince) VALUES (@Email, @Password, @FirstName, @LastName, @Birthday, @IsAdmin, @AccountBalance, @MemberSince)",
                Connection = new SqlConnection(Validation.GetConnected())
            };

            command.Parameters.AddWithValue("@Email", Email);
            command.Parameters.AddWithValue("@Password", Password);
            command.Parameters.AddWithValue("@FirstName", FirstName);
            command.Parameters.AddWithValue("@LastName", LastName);
            command.Parameters.AddWithValue("@Birthday", Birthday);
            command.Parameters.AddWithValue("@IsAdmin", _isAdmin);
            command.Parameters.AddWithValue("@AccountBalance", _accountBalance);
            command.Parameters.AddWithValue("@MemberSince", MemberSince);

            try // we will try something that requires resources beyond this program, and it may not work.
            {
                command.Connection.Open();

                SqlCommand secondCommand = new SqlCommand
                {
                    CommandText = "SELECT COUNT(*) FROM Members WHERE (Email = @Email)",
                    Connection = command.Connection
                };

                secondCommand.Parameters.AddWithValue("@Email", Email);

                int emailExists = (int)secondCommand.ExecuteScalar();

                if (emailExists > 0)
                {
                    result = "This email has already been used. Login with that email or use another one.";
                }
                else
                {
                    result = $"{command.ExecuteNonQuery()} records affected.";

                    HttpContext.Current.Session["UName"] = Email;
                    HttpContext.Current.Session["LoggedIn"] = "TRUE";
                    HttpContext.Current.Response.Redirect("/Backend/MembershipPanel.aspx");
                }
            }
            catch (Exception err) // if it does not work, we can handle the issue here.
            {
                result = $"ERROR: {err.Message}";
            }
            finally // this code runs no matter if try is successful or fails.
            {
                // once we are done, close it.
                command.Connection.Close();
            }

            return result;
        }

        /// <summary>
        /// Retrieves a member from the Members table based on the provided membership ID.
        /// </summary>
        /// <param name="intMembershipId">The membership ID of the member to retrieve.</param>
        /// <returns>A SqlDataReader containing member details for the specified membership ID.</returns>
        /// <remarks>
        /// This method establishes a connection to the database, constructs a SQL query to retrieve member details, 
        /// and returns the results as a SqlDataReader. 
        /// The caller is responsible for closing the SqlDataReader and the associated SQL connection.
        /// </remarks>
        public SqlDataReader FindMember(int intMembershipId)
        {
            SqlConnection conn = new SqlConnection();
            SqlCommand comm = new SqlCommand();

            string strConn = Validation.GetConnected();

            string sqlString = "SELECT * FROM Members WHERE Member_ID = @Member_ID;";

            conn.ConnectionString = strConn;

            comm.Connection = conn;
            comm.CommandText = sqlString;
            comm.Parameters.AddWithValue("@Member_ID", intMembershipId);

            conn.Open();

            return comm.ExecuteReader();
        }

        /// <summary>
        /// Deletes a member from the Members table based on the provided membership ID.
        /// </summary>
        /// <param name="intMembershipId">The membership ID of the member to delete.</param>
        /// <returns>A string message indicating the result of the delete operation, including any errors.</returns>
        /// <remarks>
        /// This method establishes a connection to the database, constructs a SQL query to delete a member, 
        /// and returns a string message indicating the result of the operation. 
        /// If the operation is successful, the message will indicate the number of records deleted. 
        /// In case of an error, the error message will be returned.
        /// </remarks>
        public string DeleteMember(int intMembershipId)
        {
            string results;

            SqlConnection conn = new SqlConnection();
            SqlCommand comm = new SqlCommand();

            string strConn = Validation.GetConnected();

            string sqlString = "DELETE FROM Members WHERE Member_ID = @Member_ID;";

            conn.ConnectionString = strConn;

            comm.Connection = conn;
            comm.CommandText = sqlString;
            comm.Parameters.AddWithValue("@Member_ID", intMembershipId);

            try
            {
                conn.Open();

                int intRecords = comm.ExecuteNonQuery();

                results = intRecords + " Records Deleted.";
            }
            catch (Exception err)
            {
                results = "ERROR: " + err.Message;
            }
            finally
            {
                conn.Close();
            }

            return results;
        }

        /// <summary>
        /// Updates a member's information in the Members table.
        /// </summary>
        /// <returns>A string message indicating the result of the update operation, including any errors.</returns>
        /// <remarks>
        /// This method updates the member's information based on instance-level properties such as Email, Password, FirstName, LastName, and Birthday. 
        /// It establishes a connection to the database, constructs a SQL query to update the member's information, 
        /// and returns a string message indicating the result of the operation. 
        /// If the operation is successful, a confirmation message is returned. In case of an error, the error message is returned.
        /// </remarks>
        public string UpdateMember()
        {
            string results;

            SqlCommand comm = new SqlCommand
            {
                CommandText = "UPDATE Members SET Email=@Email, Password=@Password, FirstName=@FirstName, LastName=@LastName, Birthday=@Birthday WHERE Email = @Email;",
                Connection = new SqlConnection(Validation.GetConnected())
            };

            comm.Parameters.AddWithValue("@Email", Email);
            comm.Parameters.AddWithValue("@Password", Password);
            comm.Parameters.AddWithValue("@FirstName", FirstName);
            comm.Parameters.AddWithValue("@LastName", LastName);
            comm.Parameters.AddWithValue("@Birthday", Birthday);
            comm.Parameters.AddWithValue("@Member_ID", _membershipId);

            try
            {
                comm.Connection.Open();
                comm.ExecuteNonQuery(); // Execute everything.

                results = "Information Updated";
            }
            catch (Exception err)
            {
                results = "ERROR: " + err.Message;
            }
            finally
            {
                comm.Connection.Close();
            }

            return results;
        }
    }
}