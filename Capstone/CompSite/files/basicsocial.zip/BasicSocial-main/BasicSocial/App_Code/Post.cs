﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Web.Mvc;
using BasicSocial.Backend;

namespace BasicSocial
{
    public class Post
    {
        private int _postId;
        private int _posterFrom;
        private string _postMessage;

        private static DateTime PostDate => DateTime.Now;

        public string Feedback { get; private set; } = "";

        public int Post_ID
        {
            get => _postId;
            set
            {
                if (value >= 0)
                {
                    _postId = value;
                }
                else
                {
                    Feedback += "\nERROR: Sorry you entered an invalid Post ID.";
                }
            }
        }

        public int Post_Author
        {
            get => _posterFrom;
            set
            {
                if (value >= 0)
                {
                    _posterFrom = value;
                }
                else
                {
                    Feedback += "\nERROR: Sorry you entered an invalid Post_Author ID.";
                }
            }
        }

        [AllowHtml]
        public string Post_Message
        {
            get => _postMessage;
            set
            {
                if (Validation.IsItFilledIn(value))
                {
                    _postMessage = value;
                }
                else
                {
                    Feedback += "<br>ERROR: Message must be filled in.<br>";
                }
            }
        }

        /// <summary>
        /// Retrieves posts and their associated information in a DataSet.
        /// </summary>
        /// <remarks>
        /// This method utilizes a recursive Common Table Expression (CTE) named 'RecursivePosts' to fetch posts and their associated replies. 
        /// The result includes information about each post, its author, and its relative position in the thread hierarchy.
        /// The method can fetch posts for a private feed or a public profile feed based on the parameters.
        /// </remarks>
        /// <param name="privateFeed">Boolean flag to indicate if the dataset is for a private feed.</param>
        /// <param name="publicProfileFeed">Boolean flag to indicate if the dataset is for a public profile feed.</param>
        /// <param name="publicProfileName">The name of the public profile. Used when the dataset is for a public profile feed.</param>
        /// <returns>A DataSet containing the fetched posts and their associated information.</returns>
        public static DataSet GetPosts_DS(bool privateFeed, bool publicProfileFeed, string publicProfileName)
        {
            string sqlString;
            DataSet dataSet = new DataSet();
            string emailParamValue = string.Empty;

            string baseSelect = @"
            -- Define a Common Table Expression (CTE) named 'RecursivePosts'
            WITH RecursivePosts AS 
            (
                -- Base case of the recursion: This selects all posts that are not replies.
                -- These form the root of each thread.
                SELECT Post_ID, Post_Author, Post_Message, Post_Date, 
                    IsReply, Replied_To, 0 AS DepthLevel,  -- DepthLevel starts at 0 for root posts
                    Post_ID AS TopLevelPost_ID,            -- For root posts, the TopLevelPost_ID is itself
                    CAST(ROW_NUMBER() OVER(ORDER BY Post_Date DESC) AS VARCHAR(MAX)) AS SortPath  -- Assign a unique number to each root post for sorting
                FROM Posts
                WHERE IsReply = 0

                UNION ALL

                -- Recursive case of the CTE: This fetches replies to posts and extends their sort paths.
                -- It runs repeatedly, expanding the results until no more replies to the replies (and so on) are found.
                SELECT p.Post_ID, p.Post_Author, p.Post_Message, p.Post_Date, 
                    p.IsReply, p.Replied_To, rp.DepthLevel + 1 AS DepthLevel,  -- Increment the depth as we go deeper into replies
                    rp.TopLevelPost_ID,   -- Keep the original post's ID consistent as we traverse the replies
                    CAST(rp.SortPath + '.' + 
                    RIGHT('0000' + CAST(ROW_NUMBER() OVER(PARTITION BY p.Replied_To ORDER BY p.Post_Date DESC) AS VARCHAR), 4) AS VARCHAR(MAX)) AS SortPath
                FROM Posts p
                JOIN RecursivePosts rp ON p.Replied_To = rp.Post_ID   -- Link a post to its parent (the post it's replying to)

            )
            -- After defining the CTE, we now select the results, joining with the Members table to get author details
            SELECT rp.Post_ID, rp.Post_Author, rp.Post_Message, rp.Post_Date, 
                   rp.IsReply, rp.Replied_To, m.FirstName, m.LastName, m.Email, 
                   rp.DepthLevel, rp.TopLevelPost_ID
            FROM RecursivePosts rp
            JOIN Members m ON rp.Post_Author = m.Member_ID";

            // Depending on whether it's a private feed or a public profile feed, filter and order the results
            if (privateFeed || publicProfileFeed)
            {
                sqlString = $@"{baseSelect} 
                     WHERE m.Email = @Email 
                     ORDER BY rp.SortPath"; // Order by the SortPath so that posts and their direct replies are adjacent

                emailParamValue = privateFeed ? HttpContext.Current.Session["UName"].ToString() : publicProfileName;
            }
            else
            {
                sqlString = $@"{baseSelect} 
                      ORDER BY rp.SortPath"; // Order by the SortPath so that posts and their direct replies are adjacent
            }

            using (SqlConnection conn = new SqlConnection(Validation.GetConnected()))
            {
                using (SqlCommand comm = new SqlCommand(sqlString, conn))
                {
                    if (!string.IsNullOrEmpty(emailParamValue))
                    {
                        comm.Parameters.AddWithValue("@Email", emailParamValue);
                    }

                    SqlDataAdapter da = new SqlDataAdapter(comm);
                    conn.Open();
                    da.Fill(dataSet, "Post_Temp");
                }
            }

            return dataSet;
        }

        /// <summary>
        /// Adds a new post and returns a message indicating the result of the operation.
        /// </summary>
        /// <returns>A message indicating the result of adding the post.</returns>
        public void AddPost(bool isReply, int? replyPostId)
        {
            using (SqlConnection conn = new SqlConnection(Validation.GetConnected()))
            {
                // Using string interpolation and conditional operators to directly form the SQL.
                string sql = $@"
                    INSERT INTO Posts (Post_Author, Post_Message, Post_Date, IsReply {(isReply ? ", Replied_To" : "")})
                    VALUES (@Post_Author, @Post_Message, @Post_Date, @IsReply {(isReply ? ", @Replied_To" : "")})";

                Dictionary<string, object> parameters = new Dictionary<string, object>
                {
                    { "@Post_Author", Post_Author },
                    { "@Post_Message", Post_Message },
                    { "@Post_Date", PostDate },
                    { "@IsReply", isReply ? 1 : 0 }
                };

                if (isReply)
                {
                    parameters.Add("@Replied_To", replyPostId);
                }

                SqlCommand comm = SharedFunctions.CreateSqlCommand(conn, sql, parameters);

                try
                {
                    conn.Open();
                    comm.ExecuteNonQuery();
                }
                catch (Exception err)
                {
                    ErrorLogger.Instance.LogError(err);
                }
            }
        }

        /// <summary>
        /// Deletes a specified post and its associated likes.
        /// </summary>
        /// <remarks>
        /// This method will first identify and delete any likes associated with the post, as well as likes of any posts that are replies to the original post, using a Common Table Expression (CTE).
        /// Once the likes are deleted, the method will then delete the post itself, along with any of its replies, using another CTE.
        /// </remarks>
        /// <param name="postId">The ID of the post to be deleted.</param>
        /// <exception cref="Exception">Throws an exception if there is an error during the deletion process and logs it using the ErrorLogger.</exception>
        public static void DeletePost(int postId)
        {
            try
            {
                string deleteLikes = @"
                -- Define the CTE here for the likes
                WITH RecursivePostsToDelete AS 
                (
                    SELECT Post_ID
                    FROM Posts
                    WHERE Post_ID = @Post_ID

                    UNION ALL

                    SELECT p.Post_ID
                    FROM Posts p
                    JOIN RecursivePostsToDelete rptd ON p.Replied_To = rptd.Post_ID
                )
                -- Now use the CTE immediately in a DELETE statement
                DELETE FROM Likes WHERE Post_ID IN (SELECT Post_ID FROM RecursivePostsToDelete)";

                string deletePosts = @"
                -- Define the CTE again, this time for the posts
                WITH RecursivePostsToDelete AS 
                (
                    SELECT Post_ID
                    FROM Posts
                    WHERE Post_ID = @Post_ID

                    UNION ALL

                    SELECT p.Post_ID
                    FROM Posts p
                    JOIN RecursivePostsToDelete rptd ON p.Replied_To = rptd.Post_ID
                )
                -- Again, use the CTE immediately in a DELETE statement
                DELETE FROM Posts WHERE Post_ID IN (SELECT Post_ID FROM RecursivePostsToDelete)";

                using (SqlConnection conn = new SqlConnection(Validation.GetConnected()))
                {
                    conn.Open();

                    // Due to the dependency, first delete from Likes table any associated likes
                    using (SqlCommand deleteLikesCommand = new SqlCommand(deleteLikes, conn))
                    {
                        deleteLikesCommand.Parameters.AddWithValue("@Post_ID", postId);
                        deleteLikesCommand.ExecuteNonQuery();
                    }

                    // Then, delete from Posts table
                    using (SqlCommand deletePostsCommand = new SqlCommand(deletePosts, conn))
                    {
                        deletePostsCommand.Parameters.AddWithValue("@Post_ID", postId);
                        deletePostsCommand.ExecuteNonQuery();
                    }

                    conn.Close();
                }
            }
            catch (Exception err)
            {
                ErrorLogger.Instance.LogError(err);
            }
        }
    }
}