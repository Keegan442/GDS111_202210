﻿using System;
using System.IO;

namespace BasicSocial.Backend
{
    /// <summary>
    /// Provides a thread-safe singleton class for logging errors.
    /// </summary>
    /// <remarks>
    /// This class uses lazy instantiation for both its instance and log file path. 
    /// It's sealed to prevent further inheritance.
    /// </remarks>
    public sealed class ErrorLogger
    {
        /// <summary>
        /// Represents the lazy-loaded singleton instance of the <see cref="ErrorLogger"/> class.
        /// </summary>
        private static readonly Lazy<ErrorLogger> _instance = new Lazy<ErrorLogger>(() => new ErrorLogger(), System.Threading.LazyThreadSafetyMode.ExecutionAndPublication);

        /// <summary>
        /// Represents the lazy-loaded path to the error log file.
        /// </summary>
        /// <remarks>
        /// The log file path is determined by mapping to the ~/Logs/Errors.txt path within the application's environment.
        /// </remarks>
        private readonly Lazy<string> _logFilePath = new Lazy<string>(() => System.Web.Hosting.HostingEnvironment.MapPath("~/Logs/Errors.txt"));

        /// <summary>
        /// Private constructor ensures that this class cannot be instantiated outside of itself.
        /// </summary>
        private ErrorLogger()
        {
        }

        /// <summary>
        /// Gets the singleton instance of the <see cref="ErrorLogger"/> class.
        /// </summary>
        /// <value>
        /// The single instance of the <see cref="ErrorLogger"/>.
        /// </value>
        public static ErrorLogger Instance => _instance.Value;

        /// <summary>
        /// Logs an exception's details to the error log file.
        /// </summary>
        /// <param name="ex">The exception to log.</param>
        /// <remarks>
        /// This method writes the exception's type, message, and stack trace to the log file.
        /// If there's an error while writing to the log file, it fails silently.
        /// </remarks>
        public void LogError(Exception ex)
        {
            try
            {
                string logMessage = $"Timestamp: {DateTime.Now}\r\nError Type: {ex.GetType()}\r\nError Message: {ex.Message}\r\nStack Trace: {ex.StackTrace}\r\n\r\n";

                File.AppendAllText(_logFilePath.Value, logMessage);
            }
            catch
            {
                // Nothing right now.
            }
        }
    }
}