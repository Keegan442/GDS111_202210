﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

namespace BasicSocial.Backend
{
    public partial class StaffPortal : System.Web.UI.Page
    {
        /// <summary>
        /// Handles the Page Load event.
        /// </summary>
        /// <remarks>
        /// Checks if the user is logged in. If logged in, the function determines if the user is an admin. Admins are allowed to stay and make edits or search other members. If the user isn't an admin, they're redirected to the home page. 
        /// If a "membershipID" is provided in the query string and the page isn't being posted back, the relevant member's details are fetched and displayed on the page.
        /// Non-logged-in users are redirected to the default Sign-In page.
        /// </remarks>
        /// <param name="sender">The source of the event. Generally, the page itself.</param>
        /// <param name="e">Event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["LoggedIn"] != null && Session["LoggedIn"].ToString() == "TRUE")
            {
                using (SqlConnection con = new SqlConnection(Validation.GetConnected()))
                {
                    SqlCommand cmd = new SqlCommand("SELECT * from Members where Email LIKE @Email;");
                    cmd.Parameters.AddWithValue("@Email", Session["UName"]);

                    cmd.Connection = con;
                    con.Open();

                    // this is where we check to see if our member is a VIP. Only VIPs can edit or search other members.
                    using (SqlDataReader oReader = cmd.ExecuteReader())
                    {
                        while (oReader.Read())
                        {
                            if (oReader["IsAdmin"].Equals(true))
                            {
                                //stay here
                            }
                            else
                            {
                                Response.Redirect(SharedFunctions.HomePageRedirect());
                            }
                        }

                        con.Close();
                    }
                }

                //Does id exist?
                if (!IsPostBack && Request.QueryString["membershipID"] != null)
                {
                    btnAdd.Visible = false;
                    btnAdd.Enabled = false;

                    string strMembershipId = Request.QueryString["membershipID"];
                    lblMembershipId.Text = strMembershipId;

                    int intMembershipId = Convert.ToInt32(strMembershipId);

                    Member temp = new Member();
                    SqlDataReader dr = temp.FindMember(intMembershipId);

                    while (dr.Read())
                    {
                        txtEmail.Text = dr["Email"].ToString();
                        txtPassword.Text = dr["Password"].ToString();
                        txtFirstName.Text = dr["FirstName"].ToString();
                        txtLastName.Text = dr["LastName"].ToString();

                        txtBirthday.TextMode = TextBoxMode.SingleLine;
                        txtBirthday.Text = DateTime.Parse(dr["Age"].ToString()).ToShortDateString();
                    }
                }
            }
            else
            {
                //if they are not logged in, send them to the Sign In page to log in.
                Response.Redirect("~/Default.aspx");
            }
        }

        /// <summary>
        /// Handles the Add button click event.
        /// </summary>
        /// <remarks>
        /// Creates a new Member instance with the details from the form and tries to add it to the database. If there are errors in the provided information, feedback is displayed to the user.
        /// </remarks>
        /// <param name="sender">The source of the event, in this case, the Add button.</param>
        /// <param name="e">Event data.</param>
        protected void btnAdd_Click(object sender, EventArgs e)
        {
            Member temp = new Member();

            temp.Email = txtEmail.Text;
            temp.Password = txtPassword.Text;
            temp.FirstName = txtFirstName.Text;
            temp.LastName = txtLastName.Text;

            if (txtBirthday.Text != "")
            {
                temp.Birthday = Convert.ToDateTime(txtBirthday.Text);
            }
            else
            {
                temp.Birthday = DateTime.Now;
            }

            if (temp.Feedback.Contains("ERROR:"))
            {
                lblFeedback.Text = temp.Feedback;
            }
            else
            {
                lblFeedback.Text = temp.AddMember();
            }
        }

        /// <summary>
        /// Handles the Delete button click event.
        /// </summary>
        /// <remarks>
        /// Tries to delete the member with the provided membership ID and provides feedback about the result.
        /// </remarks>
        /// <param name="sender">The source of the event, in this case, the Delete button.</param>
        /// <param name="e">Event data.</param>
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            int intMembershipId = Convert.ToInt32(lblMembershipId.Text);

            Member temp = new Member();

            lblFeedback.Text = temp.DeleteMember(intMembershipId);
        }

        /// <summary>
        /// Handles the Search button click event.
        /// </summary>
        /// <remarks>
        /// Fetches members with names matching the search criteria and binds the results to a GridView object for display.
        /// </remarks>
        /// <param name="sender">The source of the event, in this case, the Search button.</param>
        /// <param name="e">Event data.</param>
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            //****************************************************************
            // Filling a DataSet and binding it to a GridView object
            //****************************************************************
            Member temp = new Member();

            //Use the object's function to fill a DataSet object
            DataSet ds = temp.AdminSearchMembers_DS(searchName.Text);

            dgResults.DataSource = ds;                      // Point GV to the dataset
            dgResults.DataMember = ds.Tables[0].TableName;  // Point GV to the one table
            dgResults.DataBind();
        }

        /// <summary>
        /// Handles the Cancel button click event.
        /// </summary>
        /// <remarks>
        /// Redirects the user to the MemberSearch page.
        /// </remarks>
        /// <param name="sender">The source of the event, in this case, the Cancel button.</param>
        /// <param name="e">Event data.</param>
        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Backend/MemberSearch.aspx");
        }
    }
}