﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web.UI.WebControls;

namespace BasicSocial.Backend
{
    public partial class MemberSearch : System.Web.UI.Page
    {
        /// <summary>
        /// Handles the <c>Load</c> event of the <c>Page</c> control.
        /// </summary>
        /// <remarks>
        /// This method executes when the page loads. It checks if the user is logged in.
        /// If the user is logged in, the method fetches and displays member details based on any search value available in the session.
        /// If no members match the search or no search is provided, the results grid is hidden.
        /// If the user is not logged in, they are redirected to the home page.
        /// </remarks>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["LoggedIn"] != null && Session["LoggedIn"].ToString() == "TRUE")
            {
                // Hide other GridViews and display the one we want to access.
                pendingInviteResults.Visible = false;
                invitesSentResult.Visible = false;

                // Reset our results label from any previous actions on this page.
                lblResults.Text = "";

                //****************************************************************
                // Filling a DataSet and binding it to a GridView object
                //****************************************************************
                Member temp = new Member();

                //Use the object's function to fill a DataSet object

                string searchValue = string.Empty;

                if (Session["FriendSearchValue"] != null)
                {
                    searchValue = Session["FriendSearchValue"].ToString();

                    // Clear the session value if you don't need it anymore
                    Session["FriendSearchValue"] = null;
                }

                DataSet ds = temp.SearchMembers_DS(searchValue);

                dgResults.DataSource = ds; // Point GV to the dataset
                dgResults.DataMember = ds.Tables[0].TableName; // Point GV to the one table
                dgResults.DataBind();

                // If our ds (data set) is empty do not display the output.
                if (dgResults.DataSource is DataSet dataSet)
                {
                    if (dataSet.Tables.Count > 0 && dataSet.Tables[0].Rows.Count == 0)
                    {
                        dgResults.Visible = false;
                    }
                    else
                    {
                        dgResults.Visible = true;
                    }
                }
            }
            else
            {
                // If they are not logged in, send them to the home page to log in.
                Response.Redirect(SharedFunctions.HomePageRedirect());
            }
        }

        /// <summary>
        /// Retrieves a <see cref="DataSet"/> containing pending friend invite details for the current user.
        /// </summary>
        /// <returns>A <see cref="DataSet"/> containing pending friend invites where the current user is the target of the invite.</returns>
        private DataSet PendingInvites_DS()
        {
            DataSet ds = new DataSet();
            
            const string sqlString = "SELECT * FROM FriendStatus WHERE (Member_Email_To = @Member_Email_To) AND Requested = @Requested";

            // Constructing parameters for the SQL command
            Dictionary<string, object> parameters = new Dictionary<string, object>
            {
                { "@Member_Email_To", Session["UName"] },
                { "@Requested", 1 }
            };

            // Use 'using' for better resource management.
            using (SqlConnection conn = new SqlConnection(Validation.GetConnected()))
            {
                using (SqlCommand comm = SharedFunctions.CreateSqlCommand(conn, sqlString, parameters))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(comm))
                    {
                        conn.Open();

                        da.Fill(ds, "PendingInvite_Temp");
                    }
                }
            }

            return ds;
        }

        /// <summary>
        /// Handles the <c>Click</c> event of the <c>btnPendingInvites</c> button control.
        /// </summary>
        /// <remarks>
        /// When this button is clicked, the method fetches and displays pending invite details 
        /// based on the current user's email. If no invites are found, the results grid is hidden.
        /// </remarks>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void btnPendingInvites_Click(object sender, EventArgs e)
        {
            // Hide other GridViews and display the one we want to access.
            dgResults.Visible = false;
            invitesSentResult.Visible = false;

            // Reset our results label from any previous actions on this page.
            lblResults.Text = "";

            //****************************************************************
            // Filling a DataSet and binding it to a GridView object
            //****************************************************************

            DataSet ds = PendingInvites_DS();

            pendingInviteResults.DataSource = ds; // Point GV to the dataset
            pendingInviteResults.DataMember = ds.Tables[0].TableName; // Point GV to the one table
            pendingInviteResults.DataBind();

            // If our ds (data set) is empty do not display the output.
            if (pendingInviteResults.DataSource is DataSet dataSet)
            {
                if (dataSet.Tables.Count > 0 && dataSet.Tables[0].Rows.Count == 0)
                {
                    pendingInviteResults.Visible = false;
                }
                else
                {
                    pendingInviteResults.Visible = true;
                }
            }
        }

        /// <summary>
        /// Retrieves a <see cref="DataSet"/> containing details of the friend invites sent by the current user.
        /// </summary>
        /// <returns>A <see cref="DataSet"/> containing friend invites sent by the current user that are still pending.</returns>
        private DataSet InvitesSent_DS()
        {
            DataSet ds = new DataSet();
            
            const string sqlString = "SELECT * FROM FriendStatus WHERE (Member_Email_From = @Member_Email_From) AND Requested = @Requested";

            // Constructing parameters for the SQL command
            Dictionary<string, object> parameters = new Dictionary<string, object>
            {
                { "@Member_Email_From", Session["UName"] },
                { "@Requested", 1 }
            };

            // Use 'using' for better resource management.
            using (SqlConnection conn = new SqlConnection(Validation.GetConnected()))
            {
                using (SqlCommand comm = SharedFunctions.CreateSqlCommand(conn, sqlString, parameters))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(comm))
                    {
                        conn.Open();

                        da.Fill(ds, "PendingInvite_Temp");
                    }
                }
            }

            return ds;
        }

        /// <summary>
        /// Handles the <c>Click</c> event of the <c>btnInvitesSent</c> button control.
        /// </summary>
        /// <remarks>
        /// When this button is clicked, the method fetches and displays the friend invite details 
        /// that have been sent by the current user. If no invites are found, the results grid is hidden.
        /// </remarks>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void btnInvitesSent_Click(object sender, EventArgs e)
        {
            // Hide other GridViews and display the one we want to access.
            dgResults.Visible = false;
            pendingInviteResults.Visible = false;

            // Reset our results label from any previous actions on this page.
            lblResults.Text = "";

            //****************************************************************
            // Filling a DataSet and binding it to a GridView object
            //****************************************************************

            DataSet ds = InvitesSent_DS();

            invitesSentResult.DataSource = ds; // Point GV to the dataset
            invitesSentResult.DataMember = ds.Tables[0].TableName; // Point GV to the one table
            invitesSentResult.DataBind();

            // If our ds (data set) is empty do not display the output.
            if (invitesSentResult.DataSource is DataSet dataSet)
            {
                if (dataSet.Tables.Count > 0 && dataSet.Tables[0].Rows.Count == 0)
                {
                    invitesSentResult.Visible = false;
                }
                else
                {
                    invitesSentResult.Visible = true;
                }
            }
        }

        /// <summary>
        /// Handles the <c>Click</c> event of the <c>btnAddFriend</c> button control.
        /// </summary>
        /// <remarks>
        /// This method handles the logic of adding a new friend. It checks if a friend request 
        /// is already pending or if the users are already friends. If neither is the case, it sends a new friend request.
        /// The results, whether successful or not, are displayed in the <c>lblResults</c> label.
        /// </remarks>
        /// <param name="sender">The source of the event, which is the button clicked.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        protected void btnAddFriend_Click(object sender, EventArgs e)
        {
            string commandArgument = ((Button)sender).CommandArgument;
            
            using (SqlConnection conn = new SqlConnection(Validation.GetConnected()))
            {
                try
                {
                    conn.Open();

                    // Check if the current user has already sent a friend request to the target user.
                    // This is done by looking for rows in the FriendStatus table where:
                    // - The target email matches the "Member_Email_To" column.
                    // - The current user's email matches the "Member_Email_From" column.
                    // - The "Requested" column is set to true (indicating a friend request).
                    if (HasRequestOrFriendship(conn, "SELECT COUNT(*) FROM FriendStatus WHERE Member_Email_To = @Email AND Requested = @Requested AND Member_Email_From = @myEmail", commandArgument, isRequested: true))
                    {
                        lblResults.Text = "You have already sent a friend request to this user.";
                        lblResults.ForeColor = Color.Red;
                    }
                    // Check if the target user has already sent a friend request to the current user.
                    // This is done by looking for rows in the FriendStatus table where:
                    // - The target email matches the "Member_Email_From" column.
                    // - The current user's email matches the "Member_Email_To" column.
                    // - The "Requested" column is set to true (indicating a friend request).
                    else if (HasRequestOrFriendship(conn, "SELECT COUNT(*) FROM FriendStatus WHERE Member_Email_From = @Email AND Requested = @Requested AND Member_Email_To = @myEmail", commandArgument, isRequested: true))
                    {
                        lblResults.Text = "That user has already sent a friend request to you.";
                        lblResults.ForeColor = Color.Red;
                    }
                    // Check if the current user is already friends with the target user.
                    // This is done by looking for rows in the FriendStatus table where:
                    // - Either the target email matches the "Member_Email_To" or the "Member_Email_From" column.
                    // - The "IsFriend" column is set to true (indicating a friendship).
                    else if (HasRequestOrFriendship(conn, "SELECT COUNT(*) FROM FriendStatus WHERE (Member_Email_To = @Email OR Member_Email_From = @Email) AND (Member_Email_To = @myEmail OR Member_Email_From = @myEmail) AND IsFriend = @IsFriend", commandArgument, isFriend: true))
                    {
                        lblResults.Text = "You are already friends with this user.";
                        lblResults.ForeColor = Color.Red;
                    }
                    else
                    {
                        Dictionary<string, object> parameters = new Dictionary<string, object>
                        {
                            {"@Member_Email_From", Session["UName"]},
                            {"@Member_Email_To", commandArgument},
                            {"@Requested", 1},
                            {"@IsFriend", 0}
                        };

                        const string sqlString = "INSERT INTO FriendStatus (Member_Email_From, Member_Email_To, Requested, IsFriend) VALUES (@Member_Email_From, @Member_Email_To, @Requested, @IsFriend)";
                        SqlCommand cmd = SharedFunctions.CreateSqlCommand(conn, sqlString, parameters);

                        cmd.ExecuteNonQuery();

                        lblResults.Text = "Friend request sent.";
                        lblResults.ForeColor = Color.LimeGreen;

                        // Reset the data grid so the most recent request is not still there.
                        dgResults.DataSource = null;
                        dgResults.DataBind();
                        
                        // If our ds (data set) is empty do not display the output.
                        if (dgResults.DataSource is DataSet dataSet)
                        {
                            if (dataSet.Tables.Count > 0 && dataSet.Tables[0].Rows.Count == 0)
                            {
                                dgResults.Visible = false;
                            }
                            else
                            {
                                dgResults.Visible = true;
                            }
                        }
                    }
                }
                catch (Exception err)
                {
                    lblResults.Text = $"ERROR: {err.Message}";
                    lblResults.ForeColor = Color.Red;

                    ErrorLogger.Instance.LogError(err);
                }
            }
        }

        /// <summary>
        /// Determines whether the current user has an existing friend request or friendship with another user.
        /// </summary>
        /// <param name="conn">An open SQL connection.</param>
        /// <param name="query">The SQL query to execute.</param>
        /// <param name="email">The email of the other user to check for friendship status.</param>
        /// <param name="isFriend">Optional parameter to indicate checking for established friendship.</param>
        /// <param name="isRequested">Optional parameter to indicate checking for pending friend requests.</param>
        /// <returns><c>true</c> if a friend request or friendship exists; otherwise, <c>false</c>.</returns>
        private bool HasRequestOrFriendship(SqlConnection conn, string query, string email, bool? isFriend = null, bool? isRequested = null)
        {
            Dictionary<string, object> parameters = new Dictionary<string, object>
            {
                {"@Email", email},
                {"@myEmail", Session["UName"]}
            };

            if (isFriend.HasValue)
            {
                parameters.Add("@IsFriend", isFriend.Value ? 1 : 0);
            }

            if (isRequested.HasValue)
            {
                parameters.Add("@Requested", isRequested.Value ? 1 : 0);
            }

            SqlCommand cmd = SharedFunctions.CreateSqlCommand(conn, query, parameters);

            return (int)cmd.ExecuteScalar() > 0;
        }

        /// <summary>
        /// Handles the <c>Click</c> event of the <c>btnAcceptRequest</c> button control.
        /// </summary>
        /// <remarks>
        /// When this button is clicked, it accepts a pending friend request.
        /// </remarks>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="CommandEventArgs"/> instance containing the event data.</param>
        protected void btnAcceptRequest_Click(object sender, CommandEventArgs e)
        {
            AcceptFriendRequest(e.CommandArgument.ToString());

            // This will refresh our DataGrid,
            //TODO: Is there a better way?
            Response.Redirect(Request.RawUrl);
        }

        /// <summary>
        /// Accepts a pending friend request.
        /// </summary>
        /// <param name="emailFrom">The email address of the user who sent the friend request.</param>
        private void AcceptFriendRequest(string emailFrom)
        {
            const string sqlString = "UPDATE FriendStatus SET Requested=@Requested, IsFriend=@IsFriend WHERE Member_Email_From = @Member_Email_From AND Member_Email_To = @Member_Email_To;";

            Dictionary<string, object> parameters = new Dictionary<string, object>
            {
                { "@Requested", 0 },
                { "@IsFriend", 1 },
                { "@Member_Email_From", emailFrom },
                { "@Member_Email_To", Session["UName"] }
            };

            using (SqlConnection conn = new SqlConnection(Validation.GetConnected()))
            {
                try
                {
                    conn.Open();

                    SqlCommand comm = SharedFunctions.CreateSqlCommand(conn, sqlString, parameters);

                    comm.ExecuteNonQuery();
                }
                catch (Exception err)
                {
                    ErrorLogger.Instance.LogError(err);
                }
            }
        }

        /// <summary>
        /// Handles the <c>Click</c> event of the <c>btnCancelRequest</c> button control.
        /// </summary>
        /// <remarks>
        /// When this button is clicked, it cancels a pending friend request.
        /// </remarks>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="CommandEventArgs"/> instance containing the event data.</param>
        protected void btnCancelRequest_Click(object sender, CommandEventArgs e)
        {
            DeleteFriendRequest(e.CommandArgument.ToString());

            // This will refresh our DataGrid,
            //TODO: Is there a better way?
            Response.Redirect(Request.RawUrl);
        }

        /// <summary>
        /// Deletes a friend request from the database based on the provided email address of the recipient.
        /// </summary>
        /// <remarks>
        /// This method connects to the database, constructs an SQL command to delete 
        /// a friend request where the "Member_Email_To" field matches the provided email,
        /// and then executes the command.
        /// </remarks>
        /// <param name="emailTo">The email address of the user who received the friend request.</param>
        private void DeleteFriendRequest(string emailTo)
        {
            const string sqlString = "DELETE FROM FriendStatus WHERE Member_Email_To = @Member_Email_To;";

            // Constructing parameters for the SQL command
            Dictionary<string, object> parameters = new Dictionary<string, object>
            {
                { "@Member_Email_To", emailTo }
            };

            // Using 'using' for automatic resource management
            using (SqlConnection conn = new SqlConnection(Validation.GetConnected()))
            {
                try
                {
                    conn.Open();

                    // Use the CreateSqlCommand function to create the SQL command
                    SqlCommand comm = SharedFunctions.CreateSqlCommand(conn, sqlString, parameters);

                    comm.ExecuteNonQuery();
                }
                catch (Exception err)
                {
                    ErrorLogger.Instance.LogError(err);
                }
            }
        }
    }
}