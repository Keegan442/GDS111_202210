﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BasicSocial.Backend
{
    public partial class MasterFeed : Page
    {
        private List<int> ExpandedPosts
        {
            get
            {
                // Handles the "remembering" of displaying and hiding of posts with replies. 
                if (ViewState["ExpandedPosts"] is List<int> expandedPosts)
                {
                    return expandedPosts;
                }

                return new List<int>();
            }

            set => ViewState["ExpandedPosts"] = value;
        }

        /// <summary>
        /// Handles the Page Load event for the current web page.
        /// </summary>
        /// <param name="sender">The source of the event. Typically the object that raised the event.</param>
        /// <param name="e">The event data.</param>
        /// <remarks>
        /// When the page is loaded:
        /// - Certain label controls (like Member_ID, FirstName, LastName) are set to be invisible.
        /// - Checks if the user is logged in based on the "LoggedIn" session value.
        ///   - If the user is logged in and it's not a postback:
        ///     - Public posts are loaded and displayed in a grid.
        ///     - Initializes a list for tracking expanded posts.
        ///   - Fetches and displays the logged-in member's information.
        /// - If the user is not logged in:
        ///   - Any active user session data is cleared.
        ///   - The user is redirected to the home page or appropriate landing page.
        /// </remarks>
        protected void Page_Load(object sender, EventArgs e)
        {
            lblMember_ID.Visible = false;
            lblFirstName.Visible = false;
            lblLastName.Visible = false;

            if (Session["LoggedIn"] != null && Session["LoggedIn"].ToString() == "TRUE")
            {
                if (!IsPostBack)
                {
                    PopulatePostsGrid();  // Load and display public posts in the grid
                    ExpandedPosts = new List<int>(); // Initialize expanded posts list
                }

                GetMemberInfo();      // Fetch and display the logged-in member's information
            }
            else
            {
                SharedFunctions.ClearSession();  // Clear any active user session data.
                Response.Redirect(SharedFunctions.HomePageRedirect());
            }
        }

        /// <summary>
        /// Populates the data grid with public posts.
        /// </summary>
        private void PopulatePostsGrid()
        {
            using (SqlConnection con = new SqlConnection(Validation.GetConnected()))
            {
                con.Open();

                // Populate the posts grid
                DataSet ds = Post.GetPosts_DS(false, false, null);
                dgResults.DataSource = ds;
                dgResults.DataMember = ds.Tables[0].TableName;
                dgResults.DataBind();
            }
        }

        /// <summary>
        /// Retrieves and displays the current member's basic information.
        /// </summary>
        private void GetMemberInfo()
        {
            using (SqlConnection con = new SqlConnection(Validation.GetConnected()))
            {
                con.Open();

                using (SqlCommand cmd = new SqlCommand("SELECT Member_ID, FirstName, LastName from Members where Email LIKE @Email;", con))
                {
                    cmd.Parameters.AddWithValue("@Email", Session["UName"]);

                    using (SqlDataReader oReader = cmd.ExecuteReader())
                    {
                        if (oReader.Read())
                        {
                            lblMember_ID.Text = oReader["Member_ID"].ToString();
                            lblFirstName.Text = oReader["FirstName"].ToString();
                            lblLastName.Text = oReader["LastName"].ToString();
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Displays our modal and sets the hidden field action type to either Post or Reply.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ShowModal(object sender, EventArgs e)
        {
            // Check which button was clicked
            if (sender is Button)
            {
                // btnAddPost was clicked. So, it's a new post
                hfActionType.Value = "Post";
                hfPostID.Value = ""; // Reset this value
            }
            else if (sender is LinkButton linkBtn)
            {
                // btnReply was clicked. So, it's a reply
                hfActionType.Value = "Reply";
                hfPostID.Value = linkBtn.CommandArgument; // Store the Post_ID for reply
            }

            mpe.Show();
        }

        /// <summary>
        /// Handles the Click event for the btnPost button. 
        /// </summary>
        /// <param name="sender">The source of the event, typically the button that was clicked.</param>
        /// <param name="e">The event data.</param>
        /// <remarks>
        /// When the btnPost button is clicked:
        /// - Validates and retrieves the author ID from the lblMember_ID label.
        /// - Creates a new Post object with the provided post content, with the content being HTML-encoded.
        /// - If the Post object has a feedback containing an error, the error is displayed to the user.
        /// - Depending on the action type (stored in hfActionType), the method will:
        ///   - Reply to an existing post, ensuring the post ID for the reply is valid.
        ///   - Add a new post.
        /// - After processing the post or reply, the page is redirected to its raw URL to prevent re-click on browser refresh.
        /// </remarks>
        protected void btnPost_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(lblMember_ID.Text, out int authorId))
            {
                lblFeedback.Text = "ERROR: Invalid author ID.";
                return;
            }

            Post temp = new Post
            {
                Post_Author = authorId,
                Post_Message = HttpUtility.HtmlEncode(postContent.Value)
            };

            if (temp.Feedback.Contains("ERROR:"))
            {
                lblFeedback.Text = temp.Feedback;
                return;
            }

            switch (hfActionType.Value)
            {
                case "Reply":
                {
                    if (int.TryParse(hfPostID.Value, out int replyToPostId))
                    {
                        temp.AddPost(true, replyToPostId);
                    }
                    else
                    {
                        lblFeedback.Text = "ERROR: Invalid post ID for reply.";
                        return;
                    }
                    break;
                }
                case "Post":
                {
                    temp.AddPost(false, null);
                    break;
                }
                default:
                {
                    lblFeedback.Text = "ERROR: Invalid action type.";
                    return;
                }
            }

            // Prevent re-click on browser refresh
            Response.Redirect(Request.RawUrl);
        }

        /// <summary>
        /// Handles the Click event for the btnLikePost button, allowing users to like or unlike a post.
        /// </summary>
        /// <param name="sender">The source of the event, typically the LinkButton that was clicked.</param>
        /// <param name="eventArgs">The event data.</param>
        /// <remarks>
        /// When the btnLikePost button is clicked:
        /// - Retrieves the command argument from the LinkButton, which is expected to represent the post ID.
        /// - Establishes a connection to the database and checks if the current member has already liked the given post.
        /// - If the member has liked the post, the like is removed (unliked). Otherwise, a new like is added for the post.
        /// - After processing the like/unlike action, the page is redirected to its raw URL to reflect the changes on the like counter.
        /// Any encountered exceptions during the process are logged using the ErrorLogger.
        /// </remarks>
        protected void btnLikePost_Click(object sender, EventArgs eventArgs)
        {
            string commandArgument = ((LinkButton)sender).CommandArgument;
            
            string likeCheckQuery = "SELECT COUNT(*) FROM Likes WHERE Member_ID = @Member_ID AND Post_ID = @Post_ID";
            string likeInsertQuery = "INSERT INTO Likes (Member_ID, Post_ID, timestamp) VALUES (@Member_ID, @Post_ID, @timestamp)";
            string likeDeleteQuery = "DELETE FROM Likes WHERE Member_ID = @Member_ID AND Post_ID = @Post_ID";

            using (SqlConnection connection = new SqlConnection(Validation.GetConnected()))
            {
                try
                {
                    connection.Open();

                    Dictionary<string, object> parameters = new Dictionary<string, object>
                    {
                        { "@Member_ID", lblMember_ID.Text },
                        { "@Post_ID", commandArgument }
                    };

                    // Utilize the CreateSqlCommand function
                    SqlCommand checkCommand = SharedFunctions.CreateSqlCommand(connection, likeCheckQuery, parameters);

                    int alreadyLiked = (int)checkCommand.ExecuteScalar();

                    if (alreadyLiked > 0)
                    {
                        SqlCommand deleteCommand = SharedFunctions.CreateSqlCommand(connection, likeDeleteQuery, parameters);
                        deleteCommand.ExecuteNonQuery();
                    }
                    else
                    {
                        parameters["@timestamp"] = DateTime.Now;

                        SqlCommand insertCommand = SharedFunctions.CreateSqlCommand(connection, likeInsertQuery, parameters);
                        insertCommand.ExecuteNonQuery();
                    }

                    // Refresh the page in both scenarios to update the like counter.
                    Response.Redirect(Request.RawUrl, false);
                }
                catch (Exception err)
                {
                    ErrorLogger.Instance.LogError(err);
                }
            }
        }

        /// <summary>
        /// Handles the Click event for the btnDeletePost button, allowing users to delete a post.
        /// </summary>
        /// <param name="sender">The source of the event, typically the ImageButton that was clicked.</param>
        /// <param name="e">The event data.</param>
        /// <remarks>
        /// When the btnDeletePost button is clicked:
        /// - Checks if the sender is an ImageButton.
        /// - Retrieves the command argument from the ImageButton, which should represent the post ID.
        /// - If the post ID is valid, it deletes the corresponding post using the DeletePost method.
        /// - After deleting the post, the page is redirected to its raw URL to ensure the deleted post no longer appears.
        /// </remarks>
        protected void btnDeletePost_Click(object sender, EventArgs e)
        {
            if (sender is ImageButton button)
            {
                if (int.TryParse(button.CommandArgument, out int postId))
                {
                    Post.DeletePost(postId); // Call your function with the parsed integer argument

                    Response.Redirect(Request.RawUrl);
                }
            }
        }

        /// <summary>
        /// Determines the appropriate CSS class for a post based on its depth level in a conversation.
        /// </summary>
        /// <param name="depthLevel">The depth level of the post, with 0 being a top-level post.</param>
        /// <returns>The CSS class corresponding to the post's depth level.</returns>
        /// <remarks>
        /// Based on the provided depth level, the method returns the following CSS classes:
        /// - 0: "top-level-post" for a top-level post.
        /// - 1: "reply-post" for a direct reply.
        /// - 2: "deep-reply-post" for a reply of a reply.
        /// - 3: "deep-deep-reply-post" for a reply of a reply of a reply.
        /// - 4: "deepest-reply-post" for the deepest reply level.
        /// Any level beyond 4 also returns "deepest-reply-post".
        /// </remarks>
        protected string GetPostClass(int depthLevel)
        {
            switch (depthLevel)
            {
                case 0: // top-level post
                    return "top-level-post";
                case 1: // direct reply
                    return "reply-post";
                case 2: // reply of a reply
                    return "deep-reply-post";
                case 3: // reply of a reply of a reply
                    return "deep-deep-reply-post";
                case 4: // deepest reply level
                    return "deepest-reply-post";
                default: // handle deeper levels if needed
                    return "deepest-reply-post";
            }
        }

        /// <summary>
        /// Event handler for when a new item is data bound in the dgResults DataGrid.
        /// It modifies item visibility and button behaviors based on post properties.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">Event data containing the bound data item.</param>
        /// <remarks>
        /// This method:
        /// - Sets visibility of posts based on depth level and whether they are expanded.
        /// - Modifies visibility of the delete button based on email matching.
        /// - Toggles visibility between favorite and like buttons based on whether the post is already liked.
        /// - Handles visibility and text of the "Show Replies" button based on replies count and depth level.
        /// </remarks>
        protected void dgResults_ItemDataBound(object sender, DataGridItemEventArgs e)
        {
            if (e.Item.ItemType != ListItemType.Item && e.Item.ItemType != ListItemType.AlternatingItem)
            {
                return;
            }

            DataRowView rowView = e.Item.DataItem as DataRowView;
            if (rowView == null)
            {
                return;
            }

            int depthLevel = Convert.ToInt32(rowView["DepthLevel"]);
            int currentPostId = Convert.ToInt32(rowView["Post_ID"]);

            // Initially, set item visibility to false
            e.Item.Visible = false;

            // If it's a main post, show it
            if (depthLevel == 0)
            {
                e.Item.Visible = true;
            }

            List<int> expandedPosts = ViewState["ExpandedPosts"] as List<int>;
            if (expandedPosts != null && (expandedPosts.Contains(currentPostId) || IsChildOf(rowView.Row, expandedPosts)))
            {
                e.Item.Visible = true;
            }

            // Handle button visibility based on email matching
            if (e.Item.FindControl("ImageButton1") is ImageButton btnDelete)
            {
                string emailFromSession = Session["UName"] as string;
                string emailFromDataSource = rowView["Email"] as string;

                btnDelete.Visible = emailFromSession == emailFromDataSource;
            }

            // Handle visibility of favorite and like buttons
            LinkButton btnFavorite = e.Item.FindControl("LinkButton1") as LinkButton;
            LinkButton btnLike = e.Item.FindControl("btnLikePost") as LinkButton;
            if (btnFavorite != null && btnLike != null)
            {
                bool isAlreadyLiked = SharedFunctions.AlreadyLiked(currentPostId, Session["Member_ID"].ToString());

                btnFavorite.Visible = isAlreadyLiked;
                btnLike.Visible = !isAlreadyLiked;
            }

            // Handle visibility of "Show Replies" button based on replies count and depth level
            Button btnShowReplies = e.Item.FindControl("btnShowReplies") as Button;
            if (btnShowReplies != null && depthLevel == 0)
            {
                int repliesCount = SharedFunctions.FetchAllReplies(currentPostId.ToString());
                btnShowReplies.Visible = repliesCount > 0;

                // Set the text of the "Show Replies"/"Hide Replies" button
                if (expandedPosts != null && expandedPosts.Contains(currentPostId))
                {
                    btnShowReplies.Text = "Hide Replies";
                }
                else
                {
                    btnShowReplies.Text = "Show Replies";
                }
            }
            else if (btnShowReplies != null)
            {
                btnShowReplies.Visible = false; // This ensures non-top-level posts do not show the "Show Replies" button
            }
        }

        /// <summary>
        /// Event handler for the "Show Replies" button click.
        /// Toggles the visibility of the replies and updates the text of the button.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The event arguments.</param>
        /// <remarks>
        /// If the post is currently expanded (replies are visible), the method will hide the replies.
        /// Otherwise, it will show the replies.
        /// </remarks>
        protected void btnShowReplies_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            if (btn != null)
            {
                int postId = Convert.ToInt32(btn.CommandArgument);

                if (ExpandedPosts.Contains(postId))
                {
                    // If expanded, remove from the list
                    ExpandedPosts.Remove(postId);
                    btn.Text = "Show Replies";  // Set text to "Show Replies"
                }
                else
                {
                    // If not expanded, add to the list and show the replies
                    ExpandedPosts.Add(postId);
                    btn.Text = "Hide Replies";  // Set text to "Hide Replies"
                }

                // Bind the grid to show the updated data
                BindPostsGrid();
            }
        }

        /// <summary>
        /// Binds the data to the dgResults DataGrid after filtering it.
        /// </summary>
        /// <remarks>
        /// This method fetches the posts and binds them to the DataGrid after applying filtering.
        /// Filtering is based on which posts are expanded and which are not.
        /// </remarks>
        private void BindPostsGrid()
        {
            using (SqlConnection con = new SqlConnection(Validation.GetConnected()))
            {
                con.Open();

                DataSet ds = Post.GetPosts_DS(false, false, null);
                DataTable filteredTable = FilterPosts(ds.Tables[0]);

                dgResults.DataSource = filteredTable;
                dgResults.DataBind();
            }
        }

        /// <summary>
        /// Filters the source table to only include rows that should be visible.
        /// </summary>
        /// <param name="sourceTable">The original DataTable containing all posts.</param>
        /// <returns>A filtered DataTable containing only the rows that should be visible.</returns>
        /// <remarks>
        /// This method checks each row in the source table and includes it in the filtered table if it's either a top-level post or if it's expanded.
        /// </remarks>
        private DataTable FilterPosts(DataTable sourceTable)
        {
            DataTable filteredTable = sourceTable.Clone();

            foreach (DataRow row in sourceTable.Rows)
            {
                int postId = Convert.ToInt32(row["Post_ID"]);

                if (IsVisible(row, postId))
                {
                    filteredTable.ImportRow(row);
                }
            }

            return filteredTable;
        }

        /// <summary>
        /// Determines if a given post should be visible in the DataGrid.
        /// </summary>
        /// <param name="row">The DataRow representing the post.</param>
        /// <param name="postId">The ID of the post.</param>
        /// <returns>True if the post should be visible, false otherwise.</returns>
        /// <remarks>
        /// A post is visible if it's a top-level post or if it's among the expanded posts.
        /// </remarks>
        private bool IsVisible(DataRow row, int postId)
        {
            if (IsTopLevelPost(row, postId))
            {
                return true;
            }

            List<int> expandedPosts = ViewState["ExpandedPosts"] as List<int>;
            if (expandedPosts != null)
            {
                return expandedPosts.Contains(postId) || IsChildOf(row, expandedPosts);
            }

            return false;
        }

        /// <summary>
        /// Determines if a given post is a top-level post.
        /// </summary>
        /// <param name="row">The DataRow representing the post.</param>
        /// <param name="postId">The ID of the post.</param>
        /// <returns>True if the post is a top-level post (DepthLevel is 0), false otherwise.</returns>
        /// <remarks>
        /// A top-level post is defined as a post with a DepthLevel of 0. This method checks the DepthLevel and compares the provided post ID against the ID in the DataRow.
        /// </remarks>
        private bool IsTopLevelPost(DataRow row, int postId)
        {
            return Convert.ToInt32(row["Post_ID"]) == postId && Convert.ToInt32(row["DepthLevel"]) == 0;
        }

        /// <summary>
        /// Determines if the current post is a child (or descendant) of any of the posts in the provided expanded posts list.
        /// </summary>
        /// <param name="currentRow">The DataRow representing the post to be checked.</param>
        /// <param name="expandedPosts">A list of post IDs representing the expanded posts.</param>
        /// <returns>True if the post is a child or descendant of any expanded post, false otherwise.</returns>
        /// <remarks>
        /// This method works recursively to traverse up the reply chain of a post. It checks if the current post or any of its ancestors is present in the expandedPosts list.
        /// </remarks>
        private bool IsChildOf(DataRow currentRow, List<int> expandedPosts)
        {
            Stack<DataRow> rowStack = new Stack<DataRow>();
            rowStack.Push(currentRow);

            while (rowStack.Count > 0)
            {
                DataRow row = rowStack.Pop();
                object repliedToObject = row["Replied_To"];

                if (repliedToObject == DBNull.Value)
                {
                    continue;
                }

                int repliedTo = Convert.ToInt32(repliedToObject);

                if (expandedPosts.Contains(repliedTo))
                {
                    return true;
                }

                DataRow parentRow = row.Table.AsEnumerable().FirstOrDefault(r => Convert.ToInt32(r["Post_ID"]) == repliedTo);

                if (parentRow != null)
                {
                    rowStack.Push(parentRow);
                }
            }

            return false;
        }
    }
}