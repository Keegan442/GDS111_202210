﻿using System.Data.SqlClient;
using System;
using System.IO;
using System.Web;
using System.Web.SessionState;
using System.Collections.Generic;

namespace BasicSocial.Backend
{
    public abstract class SharedFunctions
    {
        /// <summary>
        /// Generates the URL for redirecting users to the home page.
        /// </summary>
        /// <returns>The URL to the home page for redirection.</returns>
        public static string HomePageRedirect()
        {
            return "~/Default.aspx";
        }

        /// <summary>
        /// Resets session variables related to user authentication.
        /// </summary>
        public static void ClearSession()
        {
            if (HttpContext.Current == null)
            {
                return;  // Exit if there's no current HTTP context
            }

            HttpSessionState session = HttpContext.Current.Session;

            if (session["UName"] != null)
            {
                session["UName"] = "";
            }

            if (session["LoggedIn"] != null)
            {
                session["LoggedIn"] = "FALSE";
            }
        }

        /// <summary>
        /// Creates and returns a SqlCommand with the provided query and parameters.
        /// </summary>
        /// <param name="connection">Database connection to be used for the command.</param>
        /// <param name="query">SQL query for the command.</param>
        /// <param name="parameters">Parameters for the query.</param>
        /// <returns>SqlCommand with the provided query and parameters.</returns>
        public static SqlCommand CreateSqlCommand(SqlConnection connection, string query, Dictionary<string, object> parameters)
        {
            SqlCommand cmd = new SqlCommand(query, connection);

            foreach (KeyValuePair<string, object> param in parameters)
            {
                cmd.Parameters.AddWithValue(param.Key, param.Value);
            }

            return cmd;
        }

        /// <summary>
        /// Retrieves the profile image URL associated with the provided email address or identifier.
        /// </summary>
        /// <param name="email">The email address or identifier linked to the profile image.</param>
        /// <returns>The URL of the profile image, or a default image URL if not found.</returns>
        public static string GetProfileImageUrl(object email)
        {
            if (email == null)
            {
                return "~/Backend/ProfilePictures/NoProfilePicture.png"; // Default image path
            }

            string emailString = email.ToString();
            string imageUrl = $"~/Backend/ProfilePictures/{emailString}.png";

            if (!File.Exists(HttpContext.Current.Server.MapPath(imageUrl)))
            {
                imageUrl = "~/Backend/ProfilePictures/NoProfilePicture.png"; // Set your default image path here
            }

            return imageUrl;
        }

        /// <summary>
        /// Checks if a member has already liked a post.
        /// </summary>
        /// <param name="postId">The ID of the post to check.</param>
        /// <param name="memberId">The ID of the member to check.</param>
        /// <returns><c>true</c> if the member has already liked the post; otherwise, <c>false</c>.</returns>
        public static bool AlreadyLiked(int postId, string memberId)
        {
            bool hasLiked = false;

            using (SqlConnection connection = new SqlConnection(Validation.GetConnected()))
            {
                using (SqlCommand command = new SqlCommand("SELECT COUNT(*) FROM Likes WHERE Member_ID = @Member_ID AND Post_ID = @Post_ID", connection))
                {
                    command.Parameters.AddWithValue("@Member_ID", memberId);
                    command.Parameters.AddWithValue("@Post_ID", postId);

                    try
                    {
                        connection.Open();
                        int alreadyLiked = (int)command.ExecuteScalar();

                        if (alreadyLiked > 0)
                        {
                            hasLiked = true;
                        }
                    }
                    catch (Exception err)
                    {
                        ErrorLogger.Instance.LogError(err);
                    }
                }
            }

            return hasLiked;
        }

        /// <summary>
        /// Fetches the total number of likes for a specific post.
        /// </summary>
        /// <param name="postId">The ID of the post for which to fetch the total likes.</param>
        /// <returns>The total number of likes for the specified post.</returns>
        public static int FetchTotalLikes(string postId)
        {
            int likes = 0;

            using (SqlConnection connection = new SqlConnection(Validation.GetConnected()))
            {
                using (SqlCommand command = new SqlCommand("SELECT COUNT(*) FROM Likes WHERE Post_ID = @Post_ID", connection))
                {
                    command.Parameters.AddWithValue("@Post_ID", postId);

                    try
                    {
                        connection.Open();
                        likes = (int)command.ExecuteScalar();
                    }
                    catch (Exception err)
                    {
                        ErrorLogger.Instance.LogError(err);
                    }
                }
            }

            return likes;
        }

        /// <summary>
        /// Retrieves the total number of direct replies for a given post ID from the database.
        /// </summary>
        /// <param name="postId">The ID of the post for which to fetch the direct replies.</param>
        /// <returns>The total number of direct replies for the specified post ID.</returns>
        private static int FetchDirectReplies(string postId)
        {
            int replies = 0;

            using (SqlConnection connection = new SqlConnection(Validation.GetConnected()))
            {
                using (SqlCommand command = new SqlCommand("SELECT COUNT(*) FROM Posts WHERE Replied_To = @Replied_To", connection))
                {
                    command.Parameters.AddWithValue("@Replied_To", postId);
                    try
                    {
                        connection.Open();
                        replies = (int)command.ExecuteScalar();
                    }
                    catch (Exception err)
                    {
                        ErrorLogger.Instance.LogError(err);
                    }
                }
            }

            return replies;
        }

        /// <summary>
        /// Recursively retrieves the total number of all replies (direct and nested) for a given post ID from the database.
        /// </summary>
        /// <param name="postId">The ID of the post for which to fetch the total replies.</param>
        /// <returns>The total number of all replies (including nested) for the specified post ID.</returns>
        public static int FetchAllReplies(string postId)
        {
            int totalReplies = FetchDirectReplies(postId);

            using (SqlConnection connection = new SqlConnection(Validation.GetConnected()))
            {
                using (SqlCommand command = new SqlCommand("SELECT Post_ID FROM Posts WHERE Replied_To = @Replied_To", connection))
                {
                    command.Parameters.AddWithValue("@Replied_To", postId);
                    try
                    {
                        connection.Open();
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                totalReplies += FetchAllReplies(reader["Post_ID"].ToString());
                            }
                        }
                    }
                    catch (Exception err)
                    {
                        ErrorLogger.Instance.LogError(err);
                    }
                }
            }

            return totalReplies;
        }
    }
}