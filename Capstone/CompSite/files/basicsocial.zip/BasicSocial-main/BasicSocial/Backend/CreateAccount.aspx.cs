﻿using System;

namespace BasicSocial.Backend
{
    public partial class CreateAccount : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        /// <summary>
        /// Event handler for the btnAdd click event.
        /// </summary>
        /// <remarks>
        /// When the "Add" button is clicked, this method is triggered. 
        /// It initializes a new instance of the Member class and sets its properties based on the input fields from the user interface.
        /// After setting the properties, it checks if the data contains errors using the Feedback property of the Member class.
        /// If no errors are found, it attempts to add the member using the AddMember method of the Member class.
        /// Feedback, whether it's from adding the member or from validation errors, is displayed to the user.
        /// </remarks>
        /// <param name="sender">The source of the event, in this case, the "Add" button.</param>
        /// <param name="e">An EventArgs object containing event data.</param>
        protected void btnAdd_Click(object sender, EventArgs e)
        {
            Member temp = new Member();

            temp.Email = txtEmail.Text;
            temp.Password = txtPassword.Text;
            temp.FirstName = txtFirstName.Text;
            temp.LastName = txtLastName.Text;

            if (txtBirthday.Text != "")
            {
                temp.Birthday = Convert.ToDateTime(txtBirthday.Text);
            }
            else
            {
                temp.Birthday = DateTime.Now;
            }

            if (temp.Feedback.Contains("ERROR:"))
            {
                lblFeedback.Text = temp.Feedback;
            }
            else
            {
                lblFeedback.Text = temp.AddMember();
            }
        }
    }
}