﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BasicSocial.Backend
{
    public partial class MembershipPanel : Page
    {
        /// <summary>
        /// Handles the Load event of the Page. Initializes UI elements and populates user-related data.
        /// </summary>
        /// <remarks>
        /// On every page load:
        /// - Certain UI elements are hidden or displayed by default.
        /// - If the user is logged in:
        ///     - Their profile information is loaded and displayed.
        ///     - Their total number of friends is calculated and shown.
        ///     - Their friend list is populated.
        ///     - Their private feed of posts is loaded.
        /// - If the user is not logged in:
        ///     - Any existing session data is cleared and the user is redirected to the default control panel page.
        /// </remarks>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">An <see cref="EventArgs"/> instance that contains the event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //This Id always remains hidden. Label is used to store variable to be passed on later.
            lblMember_ID.Visible = false;
            lblPostFirstName.Visible = false;
            lblPostLastName.Visible = false;
            lblAccountBalance.Visible = false;
            changePic.Visible = false;
            btnEditPicture.Visible = true;
            btnEditInfo.Visible = true;
            viewInfo.Visible = true;
            editInfo.Visible = false;
            lblEmail.Visible = false;
            lblPassword.Visible = false;

            if (Session["LoggedIn"] != null && Session["LoggedIn"].ToString() == "TRUE")
            {
                PopulateUserInfo(); // Fills user-related labels and sets the user's profile image.

                GetTotalNumberOfFriends(); // Retrieves and displays the total number of the user's friends.

                PopulateFriendsList(); // Populates and displays the user's friend list.

                PopulatePrivateFeed(); // Displays the user's private feed of posts.
            }
            else
            {
                SharedFunctions.ClearSession();  // Clear any active user session data.
                Response.Redirect(SharedFunctions.HomePageRedirect()); // Redirect the user to the default control panel page.
            }
        }

        /// <summary>
        /// Populates user-related information fields from the database.
        /// </summary>
        private void PopulateUserInfo()
        {
            using (SqlConnection con = new SqlConnection(Validation.GetConnected()))
            {
                Dictionary<string, object> parameters = new Dictionary<string, object> { { "@Email", Session["UName"].ToString() } };

                SqlCommand cmd = SharedFunctions.CreateSqlCommand(con, "SELECT * from Members where Email LIKE @Email", parameters);

                con.Open();

                using (SqlDataReader oReader = cmd.ExecuteReader())
                {
                    while (oReader.Read())
                    {
                        lblMember_ID.Text = oReader["Member_ID"].ToString();
                        lblAccountLoggedIn.Text = oReader["FirstName"] + "'s Page";

                        lblMemberSince.Text = DateTime.Parse(oReader["MemberSince"].ToString()).ToString("MM/dd/yyyy");
                        lblEmail.Text = oReader["Email"].ToString();
                        lblFirstName.Text = "First Name: " + oReader["FirstName"];
                        lblLastName.Text = "Last Name: " + oReader["LastName"];

                        // Duplicate labels for the Post section
                        lblPostFirstName.Text = oReader["FirstName"].ToString();
                        lblPostLastName.Text = oReader["LastName"].ToString();

                        lblBirthday.Text = "Birthday: " + DateTime.Parse(oReader["Birthday"].ToString()).ToString("MM/dd/yyyy");
                        lblAccountBalance.Text = "Account Balance: " + oReader["AccountBalance"];

                        // Update on post-back
                        if (!IsPostBack)
                        {
                            txtFirstNameChange.Text = oReader["FirstName"].ToString();
                            txtLastNameChange.Text = oReader["LastName"].ToString();
                            txtBirthday.Text = DateTime.Parse(oReader["Birthday"].ToString()).ToString("yyyy-MM-dd");
                        }

                        SetProfileImage(oReader["Email"].ToString());
                    }
                }
            }
        }

        /// <summary>
        /// Sets the profile image path based on the given email.
        /// </summary>
        /// <param name="email">Email to determine the profile image path.</param>
        private void SetProfileImage(string email)
        {
            string imagePath = Server.MapPath("~/Backend/ProfilePictures/" + email + ".png");

            if (File.Exists(imagePath))
            {
                profileImage.Src = "~/Backend/ProfilePictures/" + email + ".png";
            }
        }

        /// <summary>
        /// Calculates and displays the total number of friends for the current user.
        /// </summary>
        private void GetTotalNumberOfFriends()
        {
            using (SqlConnection connection = new SqlConnection(Validation.GetConnected()))
            {
                string query = @"SELECT COUNT(*)                               
                                 FROM FriendStatus
                                 WHERE (Member_Email_From LIKE @EmailToMatch OR Member_Email_To LIKE @EmailToMatch)
                                 AND FriendStatus.IsFriend = 1";

                Dictionary<string, object> parameters = new Dictionary<string, object> { { "@EmailToMatch", Session["UName"] } };

                SqlCommand command = SharedFunctions.CreateSqlCommand(connection, query, parameters);

                connection.Open();

                int totalFriends = (int)command.ExecuteScalar();

                lblTotalFriends.Text = totalFriends.ToString();
            }
        }

        /// <summary>
        /// Populates and displays the user's friend list on the data grid.
        /// </summary>
        /// <remarks>
        /// This method achieves the following:
        /// - Establishes a connection to the database.
        /// - Constructs a SQL query to fetch the user's friends.
        ///     - The query joins the Members and FriendStatus tables to get the list of friends.
        ///     - It identifies whether the current user is the sender or receiver of the friend relationship to correctly identify the friend's details.
        ///     - It then joins again with the Members table to get the actual names of the friend.
        /// - If the data fetch is successful, the data is bound to the `dgResults` data grid for display.
        /// - Any exceptions that occur during this process are logged.
        /// </remarks>
        private void PopulateFriendsList()
        {
            using (SqlConnection connection = new SqlConnection(Validation.GetConnected()))
            {
                DataSet ds = new DataSet();

                string query = @"SELECT Members.*, 
                                 CASE 
                                 WHEN Members.Email = FriendStatus.Member_Email_From THEN FriendStatus.Member_Email_To
                                 ELSE FriendStatus.Member_Email_From
                                 END AS Other_User_Email,
                                 OtherUser.FirstName AS Other_User_FirstName,
                                 OtherUser.LastName AS Other_User_LastName
                                 FROM Members 
                                 INNER JOIN FriendStatus 
                                 ON (Members.Email = FriendStatus.Member_Email_From OR Members.Email = FriendStatus.Member_Email_To) 
                                 AND FriendStatus.IsFriend = 1
                                 LEFT JOIN Members AS OtherUser
                                 ON OtherUser.Email = 
                                 CASE 
                                 WHEN Members.Email = FriendStatus.Member_Email_From THEN FriendStatus.Member_Email_To
                                 ELSE FriendStatus.Member_Email_From
                                 END
                                 WHERE Members.Email = @EmailToMatch;";

                Dictionary<string, object> parameters = new Dictionary<string, object>
                {
                    {"@EmailToMatch", Session["UName"]}
                };

                try
                {
                    SqlCommand comm = SharedFunctions.CreateSqlCommand(connection, query, parameters);

                    SqlDataAdapter da = new SqlDataAdapter
                    {
                        SelectCommand = comm
                    };

                    connection.Open();
                    da.Fill(ds, "Member_Temp");

                    dgResults.DataSource = ds;
                    dgResults.DataMember = ds.Tables[0].TableName;
                    dgResults.DataBind();
                }
                catch (Exception err)
                {
                    ErrorLogger.Instance.LogError(err);
                }
            }
        }

        /// <summary>
        /// Binds the private feed of posts for the current user to the data grid.
        /// </summary>
        private void PopulatePrivateFeed()
        {
            DataSet personalFeedDataSet = Post.GetPosts_DS(true, false, null);

            PersonalFeedDataGrid.DataSource = personalFeedDataSet;
            PersonalFeedDataGrid.DataMember = personalFeedDataSet.Tables[0].TableName;
            PersonalFeedDataGrid.DataBind();
        }

        /// <summary>
        /// Logout button that resets Session variables and redirects to the main page.
        /// </summary>
        protected void btnSignOut_Click(object sender, EventArgs e)
        {
            SharedFunctions.ClearSession();  // Clear any active user session data.
            Response.Redirect(SharedFunctions.HomePageRedirect()); // Redirect the user to the default control panel page.
        }

        /// <summary>
        /// Redirects the user to the MemberSearch page.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">Event data.</param>
        protected void btnFriendSearch_Click(object sender, EventArgs e)
        {
            Response.Redirect("/Backend/MemberSearch.aspx");
        }

        /// <summary>
        /// Handles the upload of user profile pictures.
        /// </summary>
        /// <remarks>
        /// This method carries out several checks:
        /// - Verifies if the uploaded file is of PNG format.
        /// - Ensures the file size is within the acceptable limit (10MB in this case).
        /// - If all checks pass, the image is saved on the server.
        /// - Any exceptions that arise during the upload process are logged.
        /// </remarks>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">Event data.</param>
        protected void btnUploadPicture_Click(object sender, EventArgs e)
        {
            const int maxFileSizeMb = 10; // 10MB file size limit

            string[] allowedExtensions = { ".png" };

            if (PhotoUpload.HasFile)
            {
                string fileExtension = Path.GetExtension(PhotoUpload.FileName).ToLower();

                if (!allowedExtensions.Contains(fileExtension))
                {
                    lblImageUpload.Text = "Please upload a valid PNG file.";
                    return;
                }

                if (PhotoUpload.PostedFile.ContentLength > maxFileSizeMb * 1024 * 1024)
                {
                    lblImageUpload.Text = $"Image is too large. Please upload an image smaller than {maxFileSizeMb}MB.";
                    return;
                }

                string savePath = Server.MapPath("~/Backend/ProfilePictures/" + Session["UName"] + fileExtension);

                try
                {
                    PhotoUpload.SaveAs(savePath);
                    lblImageUpload.Text = "Image successfully saved.";

                    // Refreshing the entire page.
                    Page.Response.Redirect(Page.Request.Url.ToString(), false);
                    Context.ApplicationInstance.CompleteRequest();
                }
                catch (Exception err)
                {
                    lblImageUpload.Text = "An error occurred while saving the image.";

                    ErrorLogger.Instance.LogError(err);
                }
            }
            else
            {
                lblImageUpload.Text = "No image saved.";
            }
        }

        /// <summary>
        /// Displays the image upload UI.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">Event data.</param>
        protected void btnEditPicture_Click(object sender, EventArgs e)
        {
            changePic.Visible = true;
            btnEditPicture.Visible = false;
        }

        /// <summary>
        /// Cancels the edit profile picture operation and hides the image upload UI.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">Event data.</param>
        protected void btnCancelEdit1_Click(object sender, EventArgs e)
        {
            changePic.Visible = false;
            btnEditPicture.Visible = true;
        }

        /// <summary>
        /// Displays the UI for editing user information.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">Event data.</param>
        protected void btnEditInfo_Click(object sender, EventArgs e)
        {
            btnEditInfo.Visible = false;
            viewInfo.Visible = false;
            editInfo.Visible = true;
        }

        /// <summary>
        /// Submits edited user information and updates the corresponding fields.
        /// </summary>
        /// <remarks>
        /// The method updates the user's details based on the provided input:
        /// - The provided information is encapsulated in the 'Member' class.
        /// - If there's an error in the provided data, feedback is given to the user.
        /// - If everything is correct, the user data is updated and the respective UI elements are refreshed to reflect these changes.
        /// </remarks>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">Event data.</param>
        protected void btnSubmitInfo_Click(object sender, EventArgs e)
        {
            Member temp = new Member();

            temp.Email = lblEmail.Text;
            temp.Password = lblPassword.Text;
            temp.FirstName = txtFirstNameChange.Text;
            temp.LastName = txtLastNameChange.Text;
            temp.Birthday = DateTime.Parse(txtBirthday.Text);

            if (temp.Feedback.Contains("ERROR:"))
            {
                lblFeedback.Text = temp.Feedback;
                lblFeedback.ForeColor = Color.Red;
            }
            else
            {
                lblFeedback.Text = temp.UpdateMember(); // Call our UpdateARecord() function.
                lblFeedback.ForeColor = Color.LimeGreen;

                //Update any changed sections.
                lblFirstName.Text = $"First Name: {temp.FirstName}";
                lblLastName.Text = $"Last Name: {temp.LastName}";
                lblBirthday.Text = $"Birthday: {temp.Birthday:MM/dd/yyyy}";
            }
        }

        /// <summary>
        /// Cancels the user info edit and reverts the UI back to the view mode.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">Event data.</param>
        protected void btnCancelEdit2_Click(object sender, EventArgs e)
        {
            btnEditInfo.Visible = true;
            viewInfo.Visible = true;
            editInfo.Visible = false;
        }

        /// <summary>
        /// Handles the 'Unfriend' action. Deletes the friend relationship between the logged-in user and the selected user.
        /// </summary>
        /// <param name="sender">The source of the event. Contains the email of the user to unfriend.</param>
        /// <param name="e">Event data.</param>
        protected void btnUnfriend_Click(object sender, EventArgs e)
        {
            string commandArgument = ((Button)sender).CommandArgument;
            string friendDeleteQuery = "DELETE FROM FriendStatus WHERE (Member_Email_From = @Member_Email_From AND Member_Email_To = @Member_Email_To) OR (Member_Email_From = @Member_Email_To AND Member_Email_To = @Member_Email_From)";

            using (SqlConnection connection = new SqlConnection(Validation.GetConnected()))
            {
                try
                {
                    connection.Open();

                    Dictionary<string, object> parameters = new Dictionary<string, object>
                    {
                        { "@Member_Email_From", Session["UName"] },
                        { "@Member_Email_To", commandArgument }
                    };
                   
                    SqlCommand deleteCommand = SharedFunctions.CreateSqlCommand(connection, friendDeleteQuery, parameters);
                    deleteCommand.ExecuteNonQuery();
                    

                    // Refresh the page in both scenarios to update the like counter.
                    Response.Redirect(Request.RawUrl, false);
                }
                catch (Exception err)
                {
                    ErrorLogger.Instance.LogError(err);
                }
            }
        }

        /// <summary>
        /// Submits a new post by the logged-in user.
        /// </summary>
        /// <remarks>
        /// The post message is HTML-encoded for safety reasons. After the post is added, the page is refreshed to reflect the new post.
        /// </remarks>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">Event data.</param>
        protected void btnPost_Click(object sender, EventArgs e)
        {
            Post temp = new Post();

            temp.Post_Author = int.Parse(lblMember_ID.Text);

            string postContentValue = postContent.Value;

            temp.Post_Message = HttpUtility.HtmlEncode(postContentValue);

            if (temp.Feedback.Contains("ERROR:"))
            {
                lblFeedback.Text = temp.Feedback;
                lblFeedback.ForeColor = Color.Red;
            }
            else
            {
                temp.AddPost(false, null);

                // If we do not do this anytime the user refreshes their browser it will "re-click" the button.
                //TODO: Is there a better way to do this?
                Response.Redirect(Request.RawUrl);
            }
        }

        /// <summary>
        /// Deletes the selected post.
        /// </summary>
        /// <param name="sender">The source of the event. Contains the ID of the post to delete.</param>
        /// <param name="e">Event data.</param>
        protected void btnDeletePost_Click(object sender, EventArgs e)
        {
            if (sender is ImageButton button)
            {
                if (int.TryParse(button.CommandArgument, out int postId))
                {
                    Post.DeletePost(postId); // Call your function with the parsed integer argument

                    Response.Redirect(Request.RawUrl);
                }
            }
        }

        /// <summary>
        /// Handles the like action for a post. Adds or removes a like from the post based on the user's previous actions.
        /// </summary>
        /// <remarks>
        /// If the post was already liked by the user, the like is removed. Otherwise, a new like is added. In both scenarios, the page is refreshed to update the like counter.
        /// </remarks>
        /// <param name="sender">The source of the event. Contains the ID of the post to like/unlike.</param>
        /// <param name="e">Event data.</param>
        protected void btnLikePost_Click(object sender, EventArgs eventArgs)
        {
            string commandArgument = ((LinkButton)sender).CommandArgument;
            
            string likeCheckQuery = "SELECT COUNT(*) FROM Likes WHERE Member_ID = @Member_ID AND Post_ID = @Post_ID";
            string likeInsertQuery = "INSERT INTO Likes (Member_ID, Post_ID, timestamp) VALUES (@Member_ID, @Post_ID, @timestamp)";
            string likeDeleteQuery = "DELETE FROM Likes WHERE Member_ID = @Member_ID AND Post_ID = @Post_ID";

            using (SqlConnection connection = new SqlConnection(Validation.GetConnected()))
            {
                try
                {
                    connection.Open();

                    Dictionary<string, object> parameters = new Dictionary<string, object>
                    {
                        { "@Member_ID", lblMember_ID.Text },
                        { "@Post_ID", commandArgument }
                    };

                    // Utilize the CreateSqlCommand function
                    SqlCommand checkCommand = SharedFunctions.CreateSqlCommand(connection, likeCheckQuery, parameters);

                    int alreadyLiked = (int)checkCommand.ExecuteScalar();

                    if (alreadyLiked > 0)
                    {
                        SqlCommand deleteCommand = SharedFunctions.CreateSqlCommand(connection, likeDeleteQuery, parameters);
                        deleteCommand.ExecuteNonQuery();
                    }
                    else
                    {
                        parameters["@timestamp"] = DateTime.Now;

                        SqlCommand insertCommand = SharedFunctions.CreateSqlCommand(connection, likeInsertQuery, parameters);
                        insertCommand.ExecuteNonQuery();
                    }

                    // Refresh the page in both scenarios to update the like counter.
                    Response.Redirect(Request.RawUrl, false);
                }
                catch (Exception err)
                {
                    ErrorLogger.Instance.LogError(err);
                }
            }
        }

        /// <summary>
        /// Customizes UI elements during the databinding process for each row of the PersonalFeed DataGrid.
        /// </summary>
        /// <remarks>
        /// This method hides or shows certain UI elements based on the user's relationship with the content.
        /// For example, it shows or hides the delete post button based on whether the logged-in user is the author of the post.
        /// </remarks>
        /// <param name="sender">The source of the event. This is the DataGrid itself.</param>
        /// <param name="e">Event data containing the current row being bound.</param>
        protected void PersonalFeedDataGrid_ItemDataBound(object sender, DataGridItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                if (e.Item.FindControl("ImageButton1") is ImageButton btnDelete)
                {
                    string emailFromSession = Session["UName"] as string;
                    string emailFromDataSource = DataBinder.Eval(e.Item.DataItem, "Email") as string;

                    btnDelete.Visible = emailFromSession == emailFromDataSource;
                }
            }

            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                LinkButton btnFavorite = e.Item.FindControl("LinkButton1") as LinkButton;
                LinkButton btnLike = e.Item.FindControl("btnLikePost") as LinkButton;

                int postId = Convert.ToInt32(DataBinder.Eval(e.Item.DataItem, "Post_ID"));

                if (btnFavorite != null && btnLike != null)
                {
                    if (SharedFunctions.AlreadyLiked(postId, Session["Member_ID"].ToString()))
                    {
                        btnFavorite.Visible = true;
                        btnLike.Visible = false;
                    }
                    else
                    {
                        btnFavorite.Visible = false;
                        btnLike.Visible = true;
                    }
                }
            }
        }
    }
}