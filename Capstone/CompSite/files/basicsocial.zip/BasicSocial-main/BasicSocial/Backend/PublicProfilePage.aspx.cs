﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Web.UI;

namespace BasicSocial.Backend
{
    public partial class PublicProfilePage : Page
    {
        /// <summary>
        /// Handles the initial loading of the page.
        /// </summary>
        /// <remarks>
        /// Checks if the user is logged in. If so, it populates the user's public information and personal feed based on the email parameter from the query string. If the user isn't logged in, any session data is cleared, and the user is redirected to the default page.
        /// </remarks>
        /// <param name="sender">The source of the event. Generally, the page itself.</param>
        /// <param name="e">Event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["LoggedIn"] != null && Session["LoggedIn"].ToString() == "TRUE")
            {
                string userEmail = Request.QueryString["user"];

                PopulatePublicInfo(userEmail); // Populate member's public information

                PopulatePersonalFeed(userEmail); // Populate user's personal feed
            }
            else
            {
                SharedFunctions.ClearSession();  // Clear any active user session data.
                Response.Redirect(SharedFunctions.HomePageRedirect()); // Redirect the user to the default control panel page.
            }
        }

        /// <summary>
        /// Populates the public profile information of the specified user.
        /// </summary>
        /// <remarks>
        /// Queries the Members table using the provided email address to get the user's details and then displays it on the page. If the user has a profile picture, it is displayed as well.
        /// </remarks>
        /// <param name="userEmail">The email of the user whose public information needs to be fetched.</param>
        private void PopulatePublicInfo(string userEmail)
        {
            using (SqlConnection con = new SqlConnection(Validation.GetConnected()))
            {
                Dictionary<string, object> parameters = new Dictionary<string, object>
                {
                    { "@Email", userEmail }
                };

                string queryString = "SELECT * from Members where Email LIKE @Email;";

                SqlCommand cmd = SharedFunctions.CreateSqlCommand(con, queryString, parameters);

                con.Open();

                using (SqlDataReader oReader = cmd.ExecuteReader())
                {
                    while (oReader.Read())
                    {
                        lblPublicProfileOwner.Text = $"{oReader["FirstName"]}'s Page";

                        DateTime memberSince = DateTime.Parse(oReader["MemberSince"].ToString());
                        lblMemberSince.Text = $"Member Since: {memberSince:MM/dd/yyyy}";

                        lblEmail.Text = $"Email: {oReader["Email"]}";

                        lblFirstName.Text = $"First Name: {oReader["FirstName"]}";
                        lblLastName.Text = $"Last Name: {oReader["LastName"]}";

                        DateTime birthday = DateTime.Parse(oReader["Birthday"].ToString());
                        lblBirthday.Text = $"Birthday: {birthday:MM/dd/yyyy}";

                        if (File.Exists(Server.MapPath($"~/Backend/ProfilePictures/{userEmail}.png")))
                        {
                            profileImage.Src = $"~/Backend/ProfilePictures/{userEmail}.png";
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Populates the personal feed of the specified user.
        /// </summary>
        /// <remarks>
        /// Calls a function to get the user's posts as a DataSet and then binds this data to the UserFeedDataGrid for display on the page.
        /// </remarks>
        /// <param name="userEmail">The email of the user whose personal feed needs to be fetched.</param>
        private void PopulatePersonalFeed(string userEmail)
        {
            DataSet personalFeedDataSet = Post.GetPosts_DS(false, true, userEmail);

            UserFeedDataGrid.DataSource = personalFeedDataSet;
            UserFeedDataGrid.DataMember = personalFeedDataSet.Tables[0].TableName;
            UserFeedDataGrid.DataBind();
        }
    }
}