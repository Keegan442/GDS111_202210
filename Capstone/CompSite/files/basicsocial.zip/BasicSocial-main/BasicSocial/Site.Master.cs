﻿using BasicSocial.Backend;
using System;
using System.Web.UI;

namespace BasicSocial
{
    public partial class SiteMaster : MasterPage
    {
        /// <summary>
        /// Handles the Page Load event.
        /// </summary>
        /// <remarks>
        /// On page load, it checks if the user is logged in. If so, the LogoutButton and myProfileLink in the NAVBAR are displayed. If the logged-in user is an admin, the staffNavButton is displayed.
        /// </remarks>
        /// <param name="sender">The source of the event, typically the page itself.</param>
        /// <param name="e">Event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["LoggedIn"] != null && Session["LoggedIn"].ToString() == "TRUE")
            {
                // If logged in display the LogoutButton in the NAVBAR otherwise they are hidden.
                LogoutButton.Visible = true;
                myProfileLink.Visible = true;

                if ((string)Session["IsAdmin"] == "TRUE")
                {
                    staffNavButton.Visible = true;
                }
            }
        }

        /// <summary>
        /// Handles the Sign Out button click event.
        /// </summary>
        /// <remarks>
        /// When clicked, it clears any active user session data and redirects the user to the default control panel page or home page.
        /// </remarks>
        /// <param name="sender">The source of the event, in this case, the Sign Out button.</param>
        /// <param name="e">Event data.</param>
        protected void btnSignOut_Click(object sender, EventArgs e)
        {
            SharedFunctions.ClearSession();  // Clear any active user session data.
            Response.Redirect(SharedFunctions.HomePageRedirect());
        }

        /// <summary>
        /// Handles the Friend Search button click event.
        /// </summary>
        /// <remarks>
        /// When the user tries to search for a friend, the entered value is stored in the session variable "FriendSearchValue" and then the user is redirected to the MemberSearch page.
        /// </remarks>
        /// <param name="sender">The source of the event, in this case, the Search Friend button.</param>
        /// <param name="e">Event data.</param>
        protected void SearchFriend_OnClick(object sender, EventArgs e)
        {
            if (txtFriendSearch != null)
            {
                Session["FriendSearchValue"] = txtFriendSearch.Text;
            }

            Response.Redirect("~/Backend/MemberSearch.aspx");
        }
    }
}