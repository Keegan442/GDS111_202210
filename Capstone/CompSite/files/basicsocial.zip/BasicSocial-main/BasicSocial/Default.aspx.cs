﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using BasicSocial.Backend;

namespace BasicSocial
{
    public partial class Default : Page
    {
        /// <summary>
        /// Handles the Page Load event.
        /// </summary>
        /// <remarks>
        /// This function checks if the "NavControl" from the Master page is present. If it is, the visibility is set to false. 
        /// If the user is already logged in, they are redirected to the MasterFeed page.
        /// </remarks>
        /// <param name="sender">The source of the event. Generally, the page itself.</param>
        /// <param name="e">Event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Master != null && Master.FindControl("NavControl") is HtmlGenericControl navbar)
            {
                navbar.Visible = false;
            }

            // If already signed in send right to membership panel. Otherwise keep here to allow sign in or sign up. 
            if (Session["LoggedIn"] != null && Session["LoggedIn"].ToString() == "TRUE")
            {
                Response.Redirect("/Backend/MasterFeed.aspx");
            }
        }

        /// <summary>
        /// Handles the Login button click event.
        /// </summary>
        /// <remarks>
        /// This function attempts to retrieve a memberId based on provided username and password. If a valid member ID is found, session variables are set accordingly and the user is redirected to the MasterFeed page.
        /// If no valid member ID is found, a feedback message is displayed.
        /// </remarks>
        /// <param name="sender">The source of the event, in this case, the Login button.</param>
        /// <param name="e">Event data.</param>
        protected void btnLogin_Click(object sender, EventArgs e)
        {
            int? memberId = GetMemberId(txtUName.Text, txtPW.Text);

            if (memberId.HasValue)
            {
                Session["UName"] = txtUName.Text;
                Session["Member_ID"] = memberId.Value;
                Session["LoggedIn"] = "TRUE";

                if (GetIsStaff())
                {
                    Session["IsAdmin"] = "TRUE";
                }
                
                Response.Redirect("~/Backend/MasterFeed.aspx");
            }
            else
            {
                Session["UName"] = "";
                Session["LoggedIn"] = "FALSE";

                lblFeedback.Text = "Login Failed. Email and password do not match.";
            }
        }

        /// <summary>
        /// Determines if the logged-in member is a staff (admin).
        /// </summary>
        /// <remarks>
        /// Fetches information about the currently logged-in member to check if they have admin rights.
        /// </remarks>
        /// <returns>Returns true if the member is an admin; otherwise, false.</returns>
        private bool GetIsStaff()
        {
            using (SqlConnection con = new SqlConnection(Validation.GetConnected()))
            {
                SqlCommand cmd = new SqlCommand("SELECT * from Members where Member_ID LIKE @Member_ID;");
                cmd.Parameters.AddWithValue("@Member_ID", Session["Member_ID"]);

                cmd.Connection = con;
                con.Open();

                // this is where we check to see if our member is a VIP. Only VIPs can edit or search other members.
                using (SqlDataReader oReader = cmd.ExecuteReader())
                {
                    while (oReader.Read())
                    {
                        if (oReader["IsAdmin"].Equals(true))
                        {
                            return true;
                        }
                    }

                    con.Close();
                }
            }

            return false;
        }

        /// <summary>
        /// Retrieves the Member ID for a given email and password.
        /// </summary>
        /// <remarks>
        /// This function queries the Members table for a member with the provided email and password. If a match is found, the member's ID is returned.
        /// </remarks>
        /// <param name="email">The email of the member.</param>
        /// <param name="password">The password of the member.</param>
        /// <returns>The ID of the member if found; otherwise, null.</returns>
        private int? GetMemberId(string email, string password)
        {
            using (SqlConnection con = new SqlConnection(Validation.GetConnected()))
            {
                const string query = "SELECT Member_ID FROM Members WHERE Email = @Email AND Password = @Password;";

                Dictionary<string, object> parameters = new Dictionary<string, object>
                {
                    { "@Email", email },
                    { "@Password", password }
                };

                SqlCommand cmd = SharedFunctions.CreateSqlCommand(con, query, parameters);

                con.Open();

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        return reader.GetInt32(reader.GetOrdinal("Member_ID"));
                    }
                }
            }

            return null; // Return null if the user is not found.
        }
    }
}